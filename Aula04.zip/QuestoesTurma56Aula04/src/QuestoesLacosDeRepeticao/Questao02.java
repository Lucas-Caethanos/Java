package QuestoesLacosDeRepeticao;
/*
Ler 10 números e imprimir quantos são pares e quantos são ímpares. (FOR)
 */
public class Questao02 {
	public static void main(String[] args) {
	
		for (int i = 0; i <= 10; i++) {
         if(i % 2 != 0){
             System.out.println(i);
         }
     }

	}
}
